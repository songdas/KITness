﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using static KiTness.Loginstate;

namespace KiTness
{
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (NameBox.Text.Length == 0)
            {
                MessageBox.Show("INSERT YOUR NAME!");
                return;
            }
            else
            {
                string name = NameBox.Text;
                string password = PasswordBox.Text;

                MySql.Data.MySqlClient.MySqlConnection sqlConnection = new MySql.Data.MySqlClient.MySqlConnection("server=localhost; userid=root; password=0314; database=kitness");
                //open the connection
                if (sqlConnection.State != System.Data.ConnectionState.Open)
                    sqlConnection.Open();

                //define the command reference
                MySql.Data.MySqlClient.MySqlCommand sqlcommand = new MySql.Data.MySqlClient.MySqlCommand();

                //define the connection used by the command object
                sqlcommand.Connection = sqlConnection;
                sqlcommand.CommandText = "SELECT * FROM user_info WHERE name = '" +name+ "' AND password = '"+password+"'";
                sqlcommand.ExecuteNonQuery();

                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = sqlcommand;
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);

                if (dataSet.Tables[0].Rows.Count > 0)
                {
                    NameBox.Text = null;
                    PasswordBox.Text = null;

                    LOGIN_STATE = 1; // 로그인상태 1로 변경
                    USERNAME = name;

                    MessageBox.Show("WELCOME "+USERNAME+"!");
                }
                else
                {
                    MessageBox.Show("Sorry! Please enter right NAME / PASSWORD!");
                    return;
                }
                sqlConnection.Close();
                NavigationService.Navigate(new MainPage());
            }
        }
    }
}