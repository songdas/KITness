﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Kinect;
using KiTness.Utilities;
using static KiTness.Loginstate;
using MySql.Data.MySqlClient;
using System.Data.OleDb;
using System.Data;
using static KiTness.Utilities.BodyDrawerManager;

namespace KiTness
{
    public partial class Workout_LungePage : Page
    {
        /// <summary>
        /// Active Kinect sensor
        /// </summary>
        private KinectSensor _sensor = null;

        /// <summary>
        /// Reader for Multisource frames
        /// </summary>
        private MultiSourceFrameReader _reader;
        private BodyDrawerManager skeletonDrawerManager = null;
        public DrawingImage BodyDrawingImage { get; private set; }

        /// <summary>
        /// IList : 배열과 arrayList기반 인터페이스. 스켈레톤 저장할 배열
        /// </summary>
        IList<Body> _bodies;
        CameraMode _mode = CameraMode.Color;

        /// <summary>
        /// Initializes a new instance of the Workout_SquatPage class
        /// </summary>
        public Workout_LungePage()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Excute start up task
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //Get the kinectSensor object
            _sensor = KinectSensor.GetDefault();

            if (_sensor != null)
            {
                //Open the sensor
                _sensor.Open();
                //Open the reader for MultiSource frames (using color, depth, infrared, body frame source type)
                _reader = _sensor.OpenMultiSourceFrameReader(
                    FrameSourceTypes.Color |
                    FrameSourceTypes.Depth |
                    FrameSourceTypes.Infrared |
                    FrameSourceTypes.Body);

                this._bodies = new Body[this._sensor.BodyFrameSource.BodyCount]; // Initialize the _bodies list

                this.skeletonDrawerManager = new BodyDrawerManager(_sensor);
                bodyDrawingImage.Source = skeletonDrawerManager.BodyDrawingImage; // this line is for both versions
                //Wire handler for frame arrival 뭔말이여
                _reader.MultiSourceFrameArrived += Reader_MultiSourceFrameArrived;
            }
        }

        /// <summary>
        /// Execute shutdown tasks
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        private void Window_Closed(object sender, EventArgs e)
        {
            if (_reader != null)
            {
                _reader.Dispose();
            }

            if (_sensor != null)
            {
                _sensor.Close();
            }
        }

        /// <summary>
        /// Handles the MultiSource frame data arriving from the sensor
        /// : 아까 사용한다고 했던 frame source type들 모두 정의해줘야함
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        void Reader_MultiSourceFrameArrived(object sender, MultiSourceFrameArrivedEventArgs e)
        {
            // Get a reference to the multi-frame
            var reference = e.FrameReference.AcquireFrame();
            // open Color frame
            using (var frame = reference.ColorFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    if (_mode == CameraMode.Color)
                    {
                        cameraDisplayImage.Source = frame.ToBitmap();
                    }
                }
            }

            // Depth
            using (var frame = reference.DepthFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    if (_mode == CameraMode.Depth)
                    {
                        cameraDisplayImage.Source = frame.ToBitmap();
                    }
                }
            }

            // Infrared
            using (var frame = reference.InfraredFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    if (_mode == CameraMode.Infrared)
                    {
                        cameraDisplayImage.Source = frame.ToBitmap();
                    }
                }
            }

            // Body
            using (var frame = reference.BodyFrameReference.AcquireFrame()) //Get a reference to the body frame
            {
                if (frame != null) // check whether the body frame is null - very important
                {
                    canvas.Children.Clear();

                    _bodies = new Body[frame.BodyFrameSource.BodyCount]; // Initialize the _bodies list

                    // The first time GetAndRefreshBodyData is called, Kinect will allocate each Body data in the array.
                    // As long as those body objects are not disposed and not set to null in the array,
                    // those body objects will be re-used. 
                    frame.GetAndRefreshBodyData(_bodies);

                    if (skeletonDrawerManager != null)
                    {
                        skeletonDrawerManager.WorkoutMode = 1;
                        skeletonDrawerManager.DrawBodies(_bodies);
                        WorkoutCount_Lunge.Text = ((int)skeletonDrawerManager.WorkoutCount).ToString();
                    }
                }
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (LOGIN_STATE == 1) // 로그인한 상태면 저장 시작
            {
                string workout = "LUNGE";
                int acc = int.Parse(skeletonDrawerManager.Accuracy);
                int count = skeletonDrawerManager.WorkoutCount;

                MySql.Data.MySqlClient.MySqlConnection sqlConnection = new MySql.Data.MySqlClient.MySqlConnection("server=localhost; userid=root; password=0314; database=kitness");

                //open the connection
                if (sqlConnection.State != System.Data.ConnectionState.Open)
                    sqlConnection.Open();

                //define the command reference
                MySql.Data.MySqlClient.MySqlCommand sqlcommand = new MySql.Data.MySqlClient.MySqlCommand();

                //define the connection used by the command object
                sqlcommand.Connection = sqlConnection;

                // INSERT QUERY
                sqlcommand.CommandText = "INSERT INTO workout_data (name, workout, accuracy, count) VALUE ('" + USERNAME + "', '" + workout + "', '" + acc + "', '" + count + "')";
                sqlcommand.ExecuteNonQuery();

                MySqlDataAdapter adapter = new MySqlDataAdapter();
                adapter.SelectCommand = sqlcommand;
                MessageBox.Show("" + USERNAME + "'s workout data was saved successfully!");
                sqlConnection.Close();
            }
            else
            {
                MessageBox.Show("Can not save your workout data.  LOG-IN FIRST ");
            }
            NavigationService.Navigate(new MainPage());
        }
    }
}