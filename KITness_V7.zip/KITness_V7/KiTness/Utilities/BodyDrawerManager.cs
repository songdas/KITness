﻿using Microsoft.Kinect;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using KiTness.Utilities;
using KiTness;

namespace KiTness.Utilities
{
    class BodyDrawerManager
    {
        #region members
        public int WorkoutMode = 0; //0 = Squat, 1 = Lunge
        public int TrackedMode = 0; //0 = Tracked correctly, 1 = Tracked but the posture is wrong

        //String user_id = null;
        int user_weight = 0;

        public int WorkoutCount = 0;
        public int SquatDown = 0, SquatUp = 0; //to make 'WorkoutCount' clear
        public int LungeDown = 0, LungeUp = 0;

        //public double cal = 0;
        //public String Calories = null;
        public double tmp = 0.0;
        public String Accuracy = null;
        public int Tot = 0;
        public int WrongTracked = 0;

        /// <summary>
        /// Radius of drawn hand circles
        /// </summary>
        private const double HandSize = 80; // original: 30

        /// <summary>
        /// Thickness of drawn joint lines
        /// </summary>
        private const double JointThickness = 10; // original: 3

        /// <summary>
        /// Thickness of clip edge rectangles
        /// </summary>
        private const double ClipBoundsThickness = 30;
        /// <summary>
        /// 투명한 색
        /// </summary>
        private Color Transparent = Color.FromArgb(0, 0, 0, 0);

        /// <summary>
        /// Brush used for drawing joints that are currently tracked
        /// </summary>
        private readonly Brush trackedJointBrush = new SolidColorBrush(Color.FromArgb(255, 68, 192, 68));
        private readonly Brush wrongPostureJointBrush = new SolidColorBrush(Color.FromArgb(255, 255, 0, 0)); // to make (wrong posture) joints RED 
        private readonly Brush TransparentGrey = new SolidColorBrush(Color.FromArgb(100, 200, 200, 200));
        private readonly Brush RedOrange = new SolidColorBrush(Color.FromArgb(150, 255, 69, 0));
        /// <summary>
        /// Brush used for drawing joints that are currently inferred
        /// </summary>        
        private readonly Brush inferredJointBrush = new SolidColorBrush(Color.FromArgb(0, 0, 0, 0));
        // inferred joint를 투명하게 draw : Color.FromArgb(A,R,G,B)에서 A가 투명도(0 완전투명,255 불투명 )

        /// <summary>
        /// Pen used for drawing bones that are currently tracked
        /// </summary>
        private readonly Pen trackedBonePen = new Pen(Brushes.LimeGreen, 8); // original: Brushes.Green, 6 
        private readonly Pen wrongPostureBonePen = new Pen(Brushes.Red, 8); // when the posture is wrong, it appears red.

        /// <summary>
        /// Pen used for drawing bones that are currently inferred
        /// </summary>        
        private readonly Pen inferredBonePen = new Pen(Brushes.Transparent, 3);

        /// <summary>
        /// Drawing group for body rendering output
        /// </summary>
        private DrawingGroup drawingGroup;

        /// <summary>
        /// Drawing image that we will display
        /// </summary>
        public DrawingImage BodyDrawingImage { get; private set; }

        /// <summary>
        /// Coordinate mapper to map one type of point to another
        /// </summary>
        private CoordinateMapper coordinateMapper = null;

        /// <summary>
        /// Width of display (depth space)
        /// </summary>
        private int displayWidth;

        /// <summary>
        /// Height of display (depth space)
        /// </summary>
        private int displayHeight;

        #endregion

        #region public methods
        /// <summary>
        /// Initializes a new instance of body drawer.
        /// To use it, bind an Image to the BodyDrawingImage property of 
        /// this instance and call its Update method for each new frame.
        /// </summary>
        public BodyDrawerManager(KinectSensor _sensor)
        {
            // get the coordinate mapper
            this.coordinateMapper = _sensor.CoordinateMapper;

            // get the depth (display) extents
            FrameDescription frameDescription = _sensor.ColorFrameSource.FrameDescription; //DepthFrameSource.FrameDescription; THIS IS IT !
            this.displayWidth = frameDescription.Width;
            this.displayHeight = frameDescription.Width;

            // Create the drawing group we'll use for drawing
            this.drawingGroup = new DrawingGroup();

            // define the drawing area's bounds (everything drawn outside won't be rendered)
            this.drawingGroup.ClipGeometry = new RectangleGeometry(new Rect(0, 0, frameDescription.Width, frameDescription.Height));

            // Create an image source that we can use in our image control
            this.BodyDrawingImage = new DrawingImage(this.drawingGroup);
        }


        /// <summary>
        /// Handles the body 
        /// data arriving from the sensor
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        public void DrawBodies(IList<Body> _bodies)
        {
            using (DrawingContext dc = this.drawingGroup.Open())
            {
                // Draw a transparent background to set the render size
                dc.DrawRectangle(Brushes.Transparent, null, new Rect(0.0, 0.0, this.displayWidth, this.displayHeight));


                foreach (Body body in _bodies)
                {
                    if (body.IsTracked)
                    {
                        this.DrawClippedEdges(body, dc);

                        IReadOnlyDictionary<JointType, Joint> joints = body.Joints;

                        // convert the joint points to depth (display) space
                        Dictionary<JointType, Point> jointPoints = new Dictionary<JointType, Point>();
                        foreach (JointType jointType in joints.Keys)
                        {
                            // use the color space joint to have a perfect mapping
                            ColorSpacePoint colorSpacePoint = this.coordinateMapper.MapCameraPointToColorSpace(joints[jointType].Position);
                            jointPoints[jointType] = new Point(colorSpacePoint.X, colorSpacePoint.Y);
                        }

                        this.DrawBody(joints, jointPoints, dc, body);
                        this.DrawAngles(joints, body, dc);

                        /////////////////////////////////////////////////////////////
                        if (WorkoutMode == 0)              //스쿼트의 경우 1회당 0.2kcal 소모 (단, 체중 50kg이하에 해당)
                        {
                            this.CountSquat(joints, body);
                            //cal = (Math.Ceiling(WorkoutCount * 0.2));
                        }
                        else if (WorkoutMode == 1)         //런지의 경우 1회당 0.21kcal 소모 (단, 체중 50kg이하에 해당)
                        {
                            this.CountLunge(joints, body);
                            //cal = (Math.Ceiling(WorkoutCount * 0.21));
                        }
                        /////////////////////////////////////////////////////////////
                        if (user_weight > 50 && user_weight <= 60)          //체중에 따른 소모 칼로리 변화
                        {
                            //cal = (Math.Ceiling(cal * 1.19));
                        }
                        else if (user_weight > 60)
                        {
                            //cal = (Math.Ceiling(cal * 1.38));
                        }

                        //dc.DrawText(new FormattedText(Tot.ToString(), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.White), new Point(100, 200));
                        //dc.DrawText(new FormattedText(WrongTracked.ToString(), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.White), new Point(100, 300));

                        tmp = Tot * 100 / (WrongTracked * 2.5 + Tot);
                        Accuracy = Math.Round(tmp).ToString(); //정확도 계산
                                                               //dc.DrawText(new FormattedText(Accuracy + "%", new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.White), new Point(100, 400));

                    }
                }
            }
        }

        public void DrawAngles(IReadOnlyDictionary<JointType, Joint> joints, Body body, DrawingContext drawingContext)
        {
            Rect rect = new Rect(40, 50, 530, 90);
            drawingContext.DrawRectangle(TransparentGrey, null, rect);

            AngleDrawerManager MyAngles = new AngleDrawerManager();
            byte leftknee = MyAngles.GetVector(body)[0];
            byte rightknee = MyAngles.GetVector(body)[1];

            if (WorkoutMode == 0)
            {
                if (leftknee < 110 && rightknee < 110)
                {
                    drawingContext.DrawText(new FormattedText((("L: " + (int)leftknee).ToString()), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.LimeGreen), new Point(50, 50));
                    drawingContext.DrawText(new FormattedText((("R: " + (int)rightknee).ToString()), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.LimeGreen), new Point(320, 50));
                }
                else
                {
                    drawingContext.DrawText(new FormattedText((("L: " + (int)leftknee).ToString()), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.Red), new Point(50, 50));
                    drawingContext.DrawText(new FormattedText((("R: " + (int)rightknee).ToString()), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.Red), new Point(320, 50));
                }
            }
            else if (WorkoutMode == 1)
            {
                if (leftknee < 120 && ((joints[JointType.AnkleLeft].Position.X) > (joints[JointType.AnkleRight].Position.X)))
                {
                    drawingContext.DrawText(new FormattedText((("L: " + (int)leftknee).ToString()), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.LimeGreen), new Point(50, 50));
                    drawingContext.DrawText(new FormattedText((("R: " + (int)rightknee).ToString()), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.LimeGreen), new Point(320, 50));
                }
                else if (rightknee < 120 && ((joints[JointType.AnkleLeft].Position.X) < (joints[JointType.AnkleRight].Position.X)))
                {
                    drawingContext.DrawText(new FormattedText((("L: " + (int)leftknee).ToString()), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.LimeGreen), new Point(50, 50));
                    drawingContext.DrawText(new FormattedText((("R: " + (int)rightknee).ToString()), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.LimeGreen), new Point(320, 50));
                }
                else
                {
                    drawingContext.DrawText(new FormattedText((("L: " + (int)leftknee).ToString()), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.Red), new Point(50, 50));
                    drawingContext.DrawText(new FormattedText((("R: " + (int)rightknee).ToString()), new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 70, Brushes.Red), new Point(320, 50));
                }
            }
        }

        // 운동 횟수 계산 메소드 for Squat
        public void CountSquat(IReadOnlyDictionary<JointType, Joint> joints, Body body)
        {
            AngleDrawerManager MyAngles = new AngleDrawerManager();
            byte leftknee = MyAngles.GetVector(body)[0];
            byte rightknee = MyAngles.GetVector(body)[1];
            int i = 0;

            if (joints[JointType.KneeLeft].Position.Y + 0.20 > joints[JointType.HipLeft].Position.Y)
            {
                SquatDown++;
            }
            else if (joints[JointType.KneeLeft].Position.Y + 0.20 < joints[JointType.HipLeft].Position.Y)
            {
                i = 1;
                SquatUp++;
            }

            if ((leftknee > 170) && (rightknee > 170) && (SquatUp > 8) && (SquatDown > 8) && (i == 1))
            {
                WorkoutCount++;
                SquatDown = 0;
                SquatUp = 0;
                i = 0;
            }
        }

        public void CountLunge(IReadOnlyDictionary<JointType, Joint> joints, Body body)
        {
            AngleDrawerManager MyAngles = new AngleDrawerManager();
            byte leftknee = MyAngles.GetVector(body)[0];
            byte rightknee = MyAngles.GetVector(body)[1];
            int i = 0;

            if ((joints[JointType.KneeLeft].Position.Y + 0.20 > joints[JointType.HipLeft].Position.Y) && ((joints[JointType.AnkleLeft].Position.X) > (joints[JointType.AnkleRight].Position.X)))
            //1-1 왼발런지 down
            {
                LungeDown++;
            }
            else if ((joints[JointType.KneeLeft].Position.Y + 0.20 < joints[JointType.HipLeft].Position.Y) && ((joints[JointType.AnkleLeft].Position.X) > (joints[JointType.AnkleRight].Position.X)))
            //1-2 왼발런지 up
            {
                i = 1;
                LungeUp++;
            }
            else if ((joints[JointType.KneeRight].Position.Y + 0.20 > joints[JointType.HipRight].Position.Y) && ((joints[JointType.AnkleLeft].Position.X) < (joints[JointType.AnkleRight].Position.X)))
            //2-1 오른발런지 down
            {
                LungeDown++;
            }
            else if ((joints[JointType.KneeRight].Position.Y + 0.20 < joints[JointType.HipRight].Position.Y) && ((joints[JointType.AnkleLeft].Position.X) < (joints[JointType.AnkleRight].Position.X)))
            //2-2 오른발런지 up
            {
                i = 1;
                LungeUp++;
            }

            if ((leftknee > 150) && (rightknee > 150) && (LungeUp > 8) && (LungeDown > 8) && (i == 1))
            {
                WorkoutCount++;
                LungeDown = 0;
                LungeUp = 0;
                i = 0;
            }
        }

        #endregion

        #region private methods
        /// <summary>
        /// Draws a body
        /// </summary>
        /// <param name="joints">joints to draw</param>
        /// <param name="jointPoints">translated positions of joints to draw</param>
        /// <param name="drawingContext">drawing context to draw to</param>
        private void DrawBody(IReadOnlyDictionary<JointType, Joint> joints, IDictionary<JointType, Point> jointPoints, DrawingContext drawingContext, Body body)
        {
            // Draw the bones

            // Torso
            this.DrawBone(joints, jointPoints, JointType.Head, JointType.Neck, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.Neck, JointType.SpineShoulder, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.SpineShoulder, JointType.SpineMid, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.SpineMid, JointType.SpineBase, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.SpineShoulder, JointType.ShoulderRight, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.SpineShoulder, JointType.ShoulderLeft, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.SpineBase, JointType.HipRight, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.SpineBase, JointType.HipLeft, drawingContext, body);

            // Right Arm    
            this.DrawBone(joints, jointPoints, JointType.ShoulderRight, JointType.ElbowRight, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.ElbowRight, JointType.WristRight, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.WristRight, JointType.HandRight, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.WristRight, JointType.ThumbRight, drawingContext, body);

            // Left Arm
            this.DrawBone(joints, jointPoints, JointType.ShoulderLeft, JointType.ElbowLeft, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.ElbowLeft, JointType.WristLeft, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.WristLeft, JointType.HandLeft, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.WristLeft, JointType.ThumbLeft, drawingContext, body);

            // Right Leg
            this.DrawBone(joints, jointPoints, JointType.HipRight, JointType.KneeRight, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.KneeRight, JointType.AnkleRight, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.AnkleRight, JointType.FootRight, drawingContext, body);

            // Left Leg
            this.DrawBone(joints, jointPoints, JointType.HipLeft, JointType.KneeLeft, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.KneeLeft, JointType.AnkleLeft, drawingContext, body);
            this.DrawBone(joints, jointPoints, JointType.AnkleLeft, JointType.FootLeft, drawingContext, body);

            // Draw the joints
            foreach (JointType jointType in joints.Keys)
            {
                Brush drawBrush = null;

                TrackingState trackingState = joints[jointType].TrackingState;

                if ((trackingState == TrackingState.Tracked) && (TrackedMode == 0))
                {
                    drawBrush = this.trackedJointBrush;
                }
                else if (trackingState == TrackingState.Inferred)
                {
                    drawBrush = this.inferredJointBrush;
                }

                if (drawBrush != null)
                {
                    drawingContext.DrawEllipse(drawBrush, null, jointPoints[jointType], JointThickness, JointThickness);
                }
            }
        }


        /// <summary>
        /// Draws one bone of a body (joint to joint)
        /// </summary>
        /// <param name="joints">joints to draw</param>
        /// <param name="jointPoints">translated positions of joints to draw</param>
        /// <param name="jointType0">first joint of bone to draw</param>
        /// <param name="jointType1">second joint of bone to draw</param>
        /// <param name="drawingContext">drawing context to draw to</param>
        private void DrawBone(IReadOnlyDictionary<JointType, Joint> joints, IDictionary<JointType, Point> jointPoints, JointType jointType0, JointType jointType1, DrawingContext drawingContext, Body body)
        {
            Joint joint0 = joints[jointType0];
            Joint joint1 = joints[jointType1];

            // If we can't find either of these joints, exit
            if (joint0.TrackingState == TrackingState.NotTracked ||
                joint1.TrackingState == TrackingState.NotTracked)
            {
                return;
            }

            // Don't draw if both points are inferred
            if (joint0.TrackingState == TrackingState.Inferred &&
                joint1.TrackingState == TrackingState.Inferred)
            {
                return;
            }

            // We assume all drawn bones are inferred unless BOTH joints are tracked
            Pen drawPen = this.inferredBonePen;

            // 하나의 Bone을 이루는 두 Joint가 tracked 일 때
            if ((joint0.TrackingState == TrackingState.Tracked) && (joint1.TrackingState == TrackingState.Tracked))
            {
                if (WorkoutMode == 0) // *************************************** squat 운동일 경우
                {
                    if (((jointType0 == JointType.SpineShoulder) && (jointType1 == JointType.ShoulderLeft)) || ((jointType0 == JointType.SpineShoulder) && (jointType1 == JointType.ShoulderRight)))
                    {
                        if (((joints[JointType.SpineShoulder].Position.Z) * 1.128 < joints[JointType.SpineBase].Position.Z))
                        // 1) 어깨와 허리 체크
                        {
                            WrongTracked++;
                            TrackedMode = 1;
                            drawPen = this.wrongPostureBonePen;
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType0], JointThickness, JointThickness);
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType1], JointThickness, JointThickness);
                            Rect rc = new Rect(1100, 50, 750, 90);
                            drawingContext.DrawRectangle(RedOrange, null, rc);
                            drawingContext.DrawText(new FormattedText("CHECK YOUR POSTURE", new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 60, Brushes.White), new Point(1120, 55));
                            //잘못된 자세- 어깨, 허리가 굽었을 때 (this should be always checked)
                        }
                        else drawPen = this.trackedBonePen; Tot++;
                    }
                    else if (((jointType0 == JointType.AnkleLeft) && (jointType1 == JointType.FootLeft)) || ((jointType0 == JointType.AnkleRight) && (jointType1 == JointType.FootRight)))
                    {
                        if ((joints[JointType.AnkleLeft].Position.X > joints[JointType.ShoulderLeft].Position.X * 1.1) || (joints[JointType.AnkleRight].Position.X < joints[JointType.ShoulderRight].Position.X * 1.1))
                        // 2) 양 발이 충분히 벌려졌는지 체크
                        {
                            WrongTracked++;
                            TrackedMode = 1;
                            drawPen = this.wrongPostureBonePen;
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType0], JointThickness, JointThickness);
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType1], JointThickness, JointThickness);
                            Rect rc = new Rect(1100, 50, 750, 90);
                            drawingContext.DrawRectangle(RedOrange, null, rc);
                            drawingContext.DrawText(new FormattedText("CHECK YOUR POSTURE", new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 60, Brushes.White), new Point(1120, 55));

                            //잘못된 자세- 양발이 어깨만큼 벌려지지 않았을 때
                        }
                        else drawPen = this.trackedBonePen; Tot++;
                    }
                    else if (((jointType0 == JointType.KneeLeft) && (jointType1 == JointType.AnkleLeft)) || ((jointType0 == JointType.KneeRight) && (jointType1 == JointType.AnkleRight)))
                    {
                        if ((joints[JointType.FootLeft].Position.X > joints[JointType.KneeLeft].Position.X) || (joints[JointType.FootRight].Position.X < joints[JointType.KneeRight].Position.X))
                        // 3) 무릎이 발 끝을 넘진 않았는지 체크
                        {
                            WrongTracked++;
                            TrackedMode = 1;
                            drawPen = this.wrongPostureBonePen;
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType0], JointThickness, JointThickness);
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType1], JointThickness, JointThickness);
                            Rect rc = new Rect(1100, 50, 750, 90);
                            drawingContext.DrawRectangle(RedOrange, null, rc);
                            drawingContext.DrawText(new FormattedText("CHECK YOUR POSTURE", new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 60, Brushes.White), new Point(1120, 55));
                            //잘못된 자세- 무릎이 발 끝을 넘었을 때
                        }
                        else drawPen = this.trackedBonePen; Tot++;
                    }
                    else drawPen = this.trackedBonePen;
                }
                else if (WorkoutMode == 1) // ********************************** lunge 운동일 경우
                {
                    if (((jointType0 == JointType.SpineShoulder) && (jointType1 == JointType.SpineMid)) || ((jointType0 == JointType.SpineMid) && (jointType1 == JointType.SpineBase)))
                    {
                        if (((joints[JointType.SpineShoulder].Position.X) * 1.128 > joints[JointType.SpineBase].Position.X))
                        // 1) 어깨와 허리 체크
                        {
                            WrongTracked++;
                            TrackedMode = 1;
                            drawPen = this.wrongPostureBonePen;
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType0], JointThickness, JointThickness);
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType1], JointThickness, JointThickness);
                            Rect rc = new Rect(1100, 50, 750, 90);
                            drawingContext.DrawRectangle(RedOrange, null, rc);
                            drawingContext.DrawText(new FormattedText("CHECK YOUR POSTURE", new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 60, Brushes.White), new Point(1120, 55));
                            //잘못된 자세- 어깨, 허리가 굽었을 때 (this should be always checked)
                        }
                        else drawPen = this.trackedBonePen; Tot++;
                    }
                    else if (((jointType0 == JointType.KneeLeft) && (jointType1 == JointType.AnkleLeft)) && ((joints[JointType.AnkleLeft].Position.X) > (joints[JointType.AnkleRight].Position.X)))
                    // 2-1) 무릎이 앞발을 넘지 않아야 함 - 왼발이 앞발일 때
                    {
                        if ((joints[JointType.KneeLeft].Position.X) > (joints[JointType.FootLeft].Position.X))
                        {
                            WrongTracked++;
                            TrackedMode = 1;
                            drawPen = this.wrongPostureBonePen;
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType0], JointThickness, JointThickness);
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType1], JointThickness, JointThickness);
                            Rect rc = new Rect(1100, 50, 750, 90);
                            drawingContext.DrawRectangle(RedOrange, null, rc);
                            drawingContext.DrawText(new FormattedText("CHECK YOUR POSTURE", new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 60, Brushes.White), new Point(1120, 55));

                        }
                        else drawPen = this.trackedBonePen; Tot++;
                    }
                    else if (((jointType0 == JointType.KneeRight) && (jointType1 == JointType.AnkleRight)) && ((joints[JointType.AnkleLeft].Position.X) < (joints[JointType.AnkleRight].Position.X)))
                    // 2-2) 무릎이 앞발을 넘지 않아야 함 - 오른발이 앞발일 때
                    {
                        if ((joints[JointType.KneeRight].Position.X) > (joints[JointType.FootRight].Position.X))
                        {
                            WrongTracked++;
                            TrackedMode = 1;
                            drawPen = this.wrongPostureBonePen;
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType0], JointThickness, JointThickness);
                            drawingContext.DrawEllipse(this.wrongPostureJointBrush, null, jointPoints[jointType1], JointThickness, JointThickness);
                            Rect rc = new Rect(1100, 50, 750, 90);
                            drawingContext.DrawRectangle(RedOrange, null, rc);
                            drawingContext.DrawText(new FormattedText("CHECK YOUR POSTURE", new System.Globalization.CultureInfo("en-us"), FlowDirection.LeftToRight, new Typeface("Verdana"), 60, Brushes.White), new Point(1120, 55));
                        }
                        else drawPen = this.trackedBonePen; Tot++;
                    }
                    else drawPen = this.trackedBonePen;
                }
                else drawPen = this.trackedBonePen;
            }
            drawingContext.DrawLine(drawPen, jointPoints[jointType0], jointPoints[jointType1]);
        }

        /// <summary>
        /// Draws a hand symbol if the hand is tracked: red circle = closed, green circle = opened; blue circle = lasso
        /// </summary>
        /// <param name="handState">state of the hand</param>
        /// <param name="handPosition">position of the hand</param>
        /// <param name="drawingContext">drawing context to draw to</param>


        /// <summary>
        /// Draws indicators to show which edges are clipping body data
        /// </summary>
        /// <param name="body">body to draw clipping information for</param>
        /// <param name="drawingContext">drawing context to draw to</param>
        private void DrawClippedEdges(Body body, DrawingContext drawingContext)
        {
            FrameEdges clippedEdges = body.ClippedEdges;

            if (clippedEdges.HasFlag(FrameEdges.Bottom))
            {
                drawingContext.DrawRectangle(
                    Brushes.Red,
                    null,
                    new Rect(0, this.displayHeight - ClipBoundsThickness, this.displayWidth, ClipBoundsThickness));
            }

            if (clippedEdges.HasFlag(FrameEdges.Top))
            {
                drawingContext.DrawRectangle(
                    Brushes.Red,
                    null,
                    new Rect(0, 0, this.displayWidth, ClipBoundsThickness));
            }

            if (clippedEdges.HasFlag(FrameEdges.Left))
            {
                drawingContext.DrawRectangle(
                    Brushes.Red,
                    null,
                    new Rect(0, 0, ClipBoundsThickness, this.displayHeight));
            }

            if (clippedEdges.HasFlag(FrameEdges.Right))
            {
                drawingContext.DrawRectangle(
                    Brushes.Red,
                    null,
                    new Rect(this.displayWidth - ClipBoundsThickness, 0, ClipBoundsThickness, this.displayHeight));
            }
        }
        #endregion

    }
}