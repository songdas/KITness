﻿using Microsoft.Kinect;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using KiTness.Utilities;
using KiTness;

namespace KiTness.Utilities
{
    class AngleDrawerManager
    {
        private DrawingGroup drawingGroup;
        public DrawingImage BodyDrawingImage { get; private set; }

        public double AngleBetweenTwoVectors(Vector3D vectorA, Vector3D vectorB)
        {
            double dotProcuct = 0.0;
            vectorA.Normalize();
            vectorB.Normalize();
            dotProcuct = Vector3D.DotProduct(vectorA, vectorB);

            return (double)Math.Acos(dotProcuct) / Math.PI * 180;
        }

        public byte[] GetVector(Body skeleton)
        {
            //KITness에서 체크하는 것 = 발목까지의 하반신
            Vector3D LeftHip = new Vector3D(skeleton.Joints[JointType.HipLeft].Position.X, skeleton.Joints[JointType.HipLeft].Position.Y, skeleton.Joints[JointType.HipLeft].Position.Z);
            Vector3D RightHip = new Vector3D(skeleton.Joints[JointType.HipRight].Position.X, skeleton.Joints[JointType.HipRight].Position.Y, skeleton.Joints[JointType.HipRight].Position.Z);
            Vector3D LeftKnee = new Vector3D(skeleton.Joints[JointType.KneeLeft].Position.X, skeleton.Joints[JointType.KneeLeft].Position.Y, skeleton.Joints[JointType.KneeLeft].Position.Z);
            Vector3D RightKnee = new Vector3D(skeleton.Joints[JointType.KneeRight].Position.X, skeleton.Joints[JointType.KneeRight].Position.Y, skeleton.Joints[JointType.KneeRight].Position.Z);
            Vector3D LeftAnkle = new Vector3D(skeleton.Joints[JointType.AnkleLeft].Position.X, skeleton.Joints[JointType.AnkleLeft].Position.Y, skeleton.Joints[JointType.AnkleLeft].Position.Z);
            Vector3D RightAnkle = new Vector3D(skeleton.Joints[JointType.AnkleRight].Position.X, skeleton.Joints[JointType.AnkleRight].Position.Y, skeleton.Joints[JointType.AnkleRight].Position.Z);

            double AngleLeftKnee = AngleBetweenTwoVectors(LeftKnee - LeftHip, LeftKnee - LeftAnkle);
            double AngleRightKnee = AngleBetweenTwoVectors(RightKnee - RightHip, RightKnee - RightAnkle);

            byte[] Angles = { Convert.ToByte(AngleLeftKnee), Convert.ToByte(AngleRightKnee) };
            return Angles;
        }
    }
}