﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace KiTness
{
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Workout_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new WorkoutPage());
        }

        private void Record_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RecordPage());
        }

        private void Join_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new JoinPage());
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new LoginPage());
        }
    }
}