﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Wpf.Samples;
using Microsoft.Kinect;
using KiTness.Utilities;
using MySql.Data.MySqlClient;
using System.Data.OleDb;
using System.Data;
using static KiTness.Loginstate;
using static KiTness.Utilities.BodyDrawerManager;

namespace KiTness
{
    public partial class WeeklyPage : Page
    {
        public WeeklyPage()
        {
            InitializeComponent();

            if (LOGIN_STATE == 1) // 로그인한 상태면 저장 시작
            {
                MySql.Data.MySqlClient.MySqlConnection sqlConnection = new MySql.Data.MySqlClient.MySqlConnection("server=localhost; userid=root; password=0314; database=kitness");

                //open the connection
                if (sqlConnection.State != System.Data.ConnectionState.Open)
                    sqlConnection.Open();

                //define the command reference
                MySql.Data.MySqlClient.MySqlCommand sqlcommand = new MySql.Data.MySqlClient.MySqlCommand();

                //define the connection used by the command object
                sqlcommand.Connection = sqlConnection;

                /*런지 계산*/
                // 일주일 총 런지 count 쿼리
                sqlcommand.CommandText = "SELECT SUM(count) FROM workout_data WHERE name = '"+USERNAME+"' AND workout = 'LUNGE' AND datetime BETWEEN ( DATE_SUB(curdate(), interval 6 day) ) AND ( DATE_ADD(curdate(), interval 1 day) )";
                int sum_LungeCount_Week = Convert.ToInt32(sqlcommand.ExecuteScalar()); // 결과값 리턴
                int avg_LungeCount_Week = (sum_LungeCount_Week) / 7;

                lungeCountSum.Text =  sum_LungeCount_Week.ToString();
                lungeCountAvg.Text = avg_LungeCount_Week.ToString();

                // 일주일 평균 런지 accuracy 쿼리
                sqlcommand.CommandText = "SELECT AVG(accuracy) FROM workout_data WHERE name = '" + USERNAME + "' AND workout = 'LUNGE' AND datetime BETWEEN ( DATE_SUB(curdate(), interval 6 day) ) AND ( DATE_ADD(curdate(), interval 1 day) )";
                int avg_LungeAccuracy_Week = Convert.ToInt32(sqlcommand.ExecuteScalar()); // 결과값 리턴
                lungeAccAvg.Text = avg_LungeAccuracy_Week.ToString();

                /*스쿼트 계산*/
                // 일주일 총 스쿼트 count 쿼리
                sqlcommand.CommandText = "SELECT SUM(count) FROM workout_data WHERE name = '" + USERNAME + "' AND workout = 'SQUAT' AND datetime BETWEEN ( DATE_SUB(curdate(), interval 6 day) ) AND ( DATE_ADD(curdate(), interval 1 day) )";
                int sum_SquatCount_Week = Convert.ToInt32(sqlcommand.ExecuteScalar()); // 결과값 리턴
                int avg_SquatCount_Week = (sum_SquatCount_Week) / 7;

                squatCountSum.Text = sum_SquatCount_Week.ToString();
                squatCountAvg.Text = avg_SquatCount_Week.ToString();

                // 일주일 평균 런지 accuracy 쿼리
                sqlcommand.CommandText = "SELECT AVG(accuracy) FROM workout_data WHERE name = '" + USERNAME + "' AND workout = 'SQUAT' AND datetime BETWEEN ( DATE_SUB(curdate(), interval 6 day) ) AND ( DATE_ADD(curdate(), interval 1 day) )";
                int avg_SquatAccuracy_Week = Convert.ToInt32(sqlcommand.ExecuteScalar()); // 결과값 리턴
                squatAccAvg.Text = avg_SquatAccuracy_Week.ToString();

                sqlConnection.Close();
            }
            else
            {
             //   MessageBox.Show("Can not access workout data. PLEASE LOG-IN FIRST! ");
            }
        }

         private void LungeButton1_Click(object sender, RoutedEventArgs e)
        {
            WeeklyLungeFrame.Visibility = System.Windows.Visibility.Visible;
            WeeklySquatFrame.Visibility = System.Windows.Visibility.Hidden;
        }

        private void SquatButton1_Click(object sender, RoutedEventArgs e)
        {
            WeeklyLungeFrame.Visibility = System.Windows.Visibility.Hidden;
            WeeklySquatFrame.Visibility = System.Windows.Visibility.Visible;
        }
    }
}