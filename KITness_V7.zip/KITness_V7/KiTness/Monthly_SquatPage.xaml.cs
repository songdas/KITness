﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Wpf.Samples;
using Microsoft.Kinect;
using KiTness.Utilities;
using MySql.Data.MySqlClient;
using System.Data.OleDb;
using System.Data;
using static KiTness.Loginstate;
using static KiTness.Utilities.BodyDrawerManager;
using Xceed.Wpf.Toolkit;
//using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Controls.Primitives;
using Xceed.Utils.XmlSerialization;
using Xceed.Wpf.Samples.SampleData;
using System.Windows.Forms;
//using System.Web.UI.DataVisualization.Charting;
using System.ComponentModel;
using System.Diagnostics;
using Xceed.Wpf.Toolkit.Chart;
using System.IO.Ports;
using System.Threading;

namespace KiTness
{
    public partial class Monthly_SquatPage : Page
    {
        public Monthly_SquatPage()
        {
            InitializeComponent();

            if (LOGIN_STATE == 1)
            {
                SquatMonthChart.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                System.Windows.MessageBox.Show("Can not access workout data. PLEASE LOG-IN FIRST! ");
            }
        }
        public DataPointsList<DataPoint> MyDate { get; set; }  
    }
}