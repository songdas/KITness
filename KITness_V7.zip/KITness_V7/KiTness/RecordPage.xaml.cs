﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace KiTness
{
    public partial class RecordPage : Page
    {
        private const String SERVER = "localhost";
        private const String DATABASE = "kitness";
        private const String ID = "root";
        private const String PASSWORD = "0314";

        public RecordPage()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }

        private void DailyButton_Click(object sender, RoutedEventArgs e)
        {
            DailyFrame.Visibility = System.Windows.Visibility.Visible;
            WeeklyFrame.Visibility = System.Windows.Visibility.Hidden;
            MonthlyFrame.Visibility = System.Windows.Visibility.Hidden;
        }

        private void WeeklyButton_Click(object sender, RoutedEventArgs e)
        {
            WeeklyFrame.Visibility = System.Windows.Visibility.Visible;
            DailyFrame.Visibility = System.Windows.Visibility.Hidden;
            MonthlyFrame.Visibility = System.Windows.Visibility.Hidden;
        }

        private void MonthlyButton_Click(object sender, RoutedEventArgs e)
        {
            MonthlyFrame.Visibility = System.Windows.Visibility.Visible;
            WeeklyFrame.Visibility = System.Windows.Visibility.Hidden;
            DailyFrame.Visibility = System.Windows.Visibility.Hidden;
        }
    }
}