﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data.OleDb;
using KiTness;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace KiTness
{
    /// <summary>
    /// SettingPage.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class JoinPage : Page
    {
        public JoinPage()
        {
            InitializeComponent(); 
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }
        // 메인폼에서 구조체를 생성
        public struct admin
        {
            public string USER_NAME;
        }

        public admin acc = new admin();

        private void Save_Click(object sender, RoutedEventArgs e)   // user_info 테이블에 입력받은 값들 insert
        {
            if (NameBox.Text.Length == 0 || PasswordBox.Text.Length == 0 || GenderBox.Text.Length == 0 || HeightBox.Text.Length == 0 || WeightBox.Text.Length == 0)
            {
                MessageBox.Show("Empty Fields Detected ! Please fill up all the fields");
                return;
            }
            else
            {
                string name = NameBox.Text;
                string password = PasswordBox.Text;
                string gender= GenderBox.Text;
                string height = HeightBox.Text;
                string weight = WeightBox.Text;

                MySql.Data.MySqlClient.MySqlConnection sqlConnection = new MySql.Data.MySqlClient.MySqlConnection("server=localhost; userid=root; password=0314; database=kitness");

                //open the connection
                if (sqlConnection.State != System.Data.ConnectionState.Open)
                    sqlConnection.Open();

                //define the command reference
                MySql.Data.MySqlClient.MySqlCommand sqlcommand = new MySql.Data.MySqlClient.MySqlCommand();

                //define the connection used by the command object
                sqlcommand.Connection = sqlConnection;

                // define the command text
                sqlcommand.CommandText = "INSERT INTO user_info(name, password, gender, height, weight) VALUES ('"+name+"', '"+password+"', '"+gender+"', '"+height+"', '"+weight+"')";

                //sqlcommand.ExecuteNonQuery();
 
                MySqlDataAdapter adapter = new MySqlDataAdapter(sqlcommand.CommandText, sqlcommand.Connection);
                adapter.SelectCommand = sqlcommand;
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);

                //if (dataSet.Tables[0].Rows.Count > 0)
                //{
                    // empty the text boxes
                    NameBox.Text = null;
                    PasswordBox.Text = null;
                    GenderBox.Text = null;
                    HeightBox.Text = null;
                    WeightBox.Text = null;

                    MessageBox.Show("JOIN SUCCESS!");
                /*}
                else
                {
                    MessageBox.Show("JOIN DENIED! INSERT right data!");
                    return;
                }*/
                sqlConnection.Close();

                NavigationService.Navigate(new MainPage());
            }
        }
    }
}