﻿using System.Windows;

namespace KiTness
{
    public partial class App : Application
    {
    }
}