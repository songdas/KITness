﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Wpf.Samples;
using Microsoft.Kinect;
using KiTness.Utilities;
using MySql.Data.MySqlClient;
using System.Data.OleDb;
using System.Data;
using static KiTness.Loginstate;
using static KiTness.Utilities.BodyDrawerManager;
using Xceed.Wpf.Toolkit;
//using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Controls.Primitives;
using Xceed.Utils.XmlSerialization;
using Xceed.Wpf.Samples.SampleData;
using System.Windows.Forms;
//using System.Web.UI.DataVisualization.Charting;
using System.ComponentModel;
using System.Diagnostics;
using Xceed.Wpf.Toolkit.Chart;
using System.IO.Ports;
using System.Threading;

namespace KiTness
{
    public partial class MonthlyPage : Page
    {
        public MonthlyPage()
        {
            InitializeComponent();

            if (LOGIN_STATE == 1) // 로그인한 상태면 저장 시작
            {
                MySql.Data.MySqlClient.MySqlConnection sqlConnection = new MySql.Data.MySqlClient.MySqlConnection("server=localhost; userid=root; password=0314; database=kitness");

                //open the connection
                if (sqlConnection.State != System.Data.ConnectionState.Open)
                    sqlConnection.Open();

                //define the command reference
                MySql.Data.MySqlClient.MySqlCommand sqlcommand = new MySql.Data.MySqlClient.MySqlCommand();

                //define the connection used by the command object
                sqlcommand.Connection = sqlConnection;

                /*런지 계산*/
                // 한달 총 런지 count 쿼리
                sqlcommand.CommandText = "SELECT SUM(count) FROM workout_data WHERE MONTH(datetime) = MONTH(CURRENT_TIMESTAMP()) AND name = '"+USERNAME+"' AND workout = 'LUNGE' ";
                int sum_LungeCount_Month = Convert.ToInt32(sqlcommand.ExecuteScalar()); // 결과값 리턴

                // 한달 중 런지한 day 카운트
                sqlcommand.CommandText = "SELECT COUNT(DISTINCT(DAY(datetime))) FROM workout_data WHERE MONTH(datetime) = MONTH(CURRENT_TIMESTAMP()) AND name = '" + USERNAME+"' AND workout = 'LUNGE'";
                int count_LungeDay = Convert.ToInt32(sqlcommand.ExecuteScalar()); // 결과값 리턴
                int avg_LungeCount_Month = (sum_LungeCount_Month) / count_LungeDay;

                lungeCountSum.Text = sum_LungeCount_Month.ToString();
                lungeCountAvg.Text = avg_LungeCount_Month.ToString();

                // 한달 평균 런지 accuracy 쿼리
                sqlcommand.CommandText = "SELECT AVG(accuracy) FROM workout_data WHERE MONTH(datetime) = MONTH(CURRENT_TIMESTAMP()) AND name = '" + USERNAME+"' AND workout = 'LUNGE'";
                int avg_LungeAccuracy_Month = Convert.ToInt32(sqlcommand.ExecuteScalar()); // 결과값 리턴
                lungeAccAvg.Text = avg_LungeAccuracy_Month.ToString();

                /*스쿼트 계산*/
                // 한달 총 스쿼트 count 쿼리
                sqlcommand.CommandText = "SELECT SUM(count) FROM workout_data WHERE MONTH(datetime) = MONTH(current_timestamp()) AND name = '"+USERNAME+"' AND workout = 'SQUAT'";
                int sum_SquatCount_Month = Convert.ToInt32(sqlcommand.ExecuteScalar()); // 결과값 리턴

                // 한달 중 스쿼트한 day 카운트
                sqlcommand.CommandText = "SELECT COUNT(DISTINCT(DAY(datetime))) FROM workout_data WHERE MONTH(datetime) = MONTH(CURRENT_TIMESTAMP()) AND name = '" + USERNAME + "' AND workout = 'SQUAT'";
                int count_SquatDay = Convert.ToInt32(sqlcommand.ExecuteScalar()); // 결과값 리턴
                int avg_SquatCount_Month = (sum_SquatCount_Month) / count_SquatDay;

                squatCountSum.Text = sum_SquatCount_Month.ToString();
                squatCountAvg.Text = avg_SquatCount_Month.ToString();

                // 일주일 평균 스쿼트 accuracy 쿼리
                sqlcommand.CommandText = "SELECT AVG(accuracy) FROM workout_data WHERE MONTH(datetime) = MONTH(current_timestamp()) AND name = '"+USERNAME+"' AND workout = 'SQUAT'";
                int avg_SquatAccuracy_Month = Convert.ToInt32(sqlcommand.ExecuteScalar()); // 결과값 리턴
                squatAccAvg.Text = avg_SquatAccuracy_Month.ToString();

                sqlConnection.Close();
            }
            else
            {
              //  System.Windows.MessageBox.Show("Can not access workout data. PLEASE LOG-IN FIRST! ");
            }
        }

        private void LungeButton1_Click(object sender, RoutedEventArgs e)
        {
            MonthlyLungeFrame.Visibility = System.Windows.Visibility.Visible;
            MonthlySquatFrame.Visibility = System.Windows.Visibility.Hidden;
          //  System.Windows.MessageBox.Show("lunge chart success!");
        }

        private void SquatButton1_Click(object sender, RoutedEventArgs e)
        {
            MonthlySquatFrame.Visibility = System.Windows.Visibility.Visible;
            MonthlyLungeFrame.Visibility = System.Windows.Visibility.Hidden;
         //   System.Windows.MessageBox.Show("squat chart success!");
        }
    }
}