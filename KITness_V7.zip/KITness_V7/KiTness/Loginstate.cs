﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KiTness
{
    public class Loginstate
    {
        public static string USERNAME;
        public static int LOGIN_STATE = 0;
        public Loginstate()
        {
        }
    }
}