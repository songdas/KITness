﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Xceed.Wpf.Samples;
using Microsoft.Kinect;
using KiTness.Utilities;
using MySql.Data.MySqlClient;
using System.Data.OleDb;
using System.Data;
using static KiTness.Loginstate;


namespace KiTness
{
    /// <summary>
    /// DailyPage.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class DailyPage : Page
    {
        private DrawingGroup drawingGroup = new DrawingGroup();
        //String[] workout_count = { null, null, null, null };
        //String[] workout_accuracy = {null, null, null, null}; // db에서 가져온 데이터를 저장할 두 배열, 하루에 각 운동은 최대 4회로 제한을 둔다
        String[] times = { null, null, null, null };

        public DailyPage()
        {
            InitializeComponent();

            if (Loginstate.LOGIN_STATE == 1)
            {
                MySql.Data.MySqlClient.MySqlConnection sqlConnection = new MySql.Data.MySqlClient.MySqlConnection("server=localhost; userid=root; password=0314; database=kitness");

                //open the connection
                if (sqlConnection.State != System.Data.ConnectionState.Open)
                    sqlConnection.Open();

                //define the command reference
                MySql.Data.MySqlClient.MySqlCommand sqlcommand = new MySql.Data.MySqlClient.MySqlCommand();

                //define the connection used by the command object 
                sqlcommand.Connection = sqlConnection;


                // user의 당일 lunge 운동 count 기록
                sqlcommand.CommandText = "SELECT count FROM workout_data WHERE name = '" + USERNAME + "' AND workout = 'LUNGE' AND datetime between (curdate()) and (date_add(curdate(), interval 1 day))";

                MySqlDataAdapter adapter1 = new MySqlDataAdapter(sqlcommand.CommandText, sqlcommand.Connection);
                DataTable dt1 = new DataTable();
                adapter1.Fill(dt1);

                DataRow dr;
                int index = dt1.Rows.Count;
                for (int i = 0; i < index && dt1.Rows[i] != null; i++)
                {
                    dr = dt1.Rows[i];
                    times[i] = dr["count"].ToString();
                }


                if (times[0] != null)
                {
                    lunge_times_1st.Text = times[0];
                }
                if (times[1] != null)
                {
                    lunge_times_2nd.Text = times[1];
                }
                if (times[2] != null)
                {
                    lunge_times_3rd.Text = times[2];
                }
                if (times[3] != null)
                {
                    lunge_times_4th.Text = times[3];
                }



                // user의 당일 lunge 운동 accuracy 기록
                sqlcommand.CommandText = "SELECT accuracy FROM workout_data WHERE name = '" + USERNAME + "' AND workout = 'LUNGE' AND datetime between (curdate()) and (date_add(curdate(), interval 1 day))";

                MySqlDataAdapter adapter2 = new MySqlDataAdapter(sqlcommand.CommandText, sqlcommand.Connection);
                DataTable dt2 = new DataTable();
                adapter2.Fill(dt2);
                
                index = dt2.Rows.Count;
                for (int i = 0; i < index && dt2.Rows[i] != null; i++)
                {
                    dr = dt2.Rows[i];
                    times[i] = dr["accuracy"].ToString();
                }


                if (times[0] != null)
                {
                    lunge_accuracy_1st.Text = times[0];
                }
                if (times[1] != null)
                {
                    lunge_accuracy_2nd.Text = times[1];
                }
                if (times[2] != null)
                {
                    lunge_accuracy_3rd.Text = times[2];
                }
                if (times[3] != null)
                {
                    lunge_accuracy_4th.Text = times[3];
                }

                // user의 당일 squat 운동 count 기록
                sqlcommand.CommandText = "SELECT count FROM workout_data WHERE name = '" + USERNAME + "' AND workout = 'SQUAT' AND datetime between (curdate()) and (date_add(curdate(), interval 1 day))";

                MySqlDataAdapter adapter3 = new MySqlDataAdapter(sqlcommand.CommandText, sqlcommand.Connection);
                DataTable dt3 = new DataTable();
                adapter3.Fill(dt3);

                index = dt3.Rows.Count;
                for (int i = 0; i < index && dt3.Rows[i] != null; i++)
                {
                    dr = dt3.Rows[i];
                    times[i] = dr["count"].ToString();
                }

                if (times[0] != null)
                {
                    squat_times_1st.Text = times[0];
                }
                if (times[1] != null)
                {
                    squat_times_2nd.Text = times[1];
                }
                if (times[2] != null)
                {
                    squat_times_3rd.Text = times[2];
                }
                if (times[3] != null)
                {
                    squat_times_4th.Text = times[3];
                }

                // user의 당일 squat 운동 accuracy 기록
                sqlcommand.CommandText = "SELECT accuracy FROM workout_data WHERE name = '" + USERNAME + "' AND workout = 'SQUAT' AND datetime between (curdate()) and (date_add(curdate(), interval 1 day))";

                MySqlDataAdapter adapter4 = new MySqlDataAdapter(sqlcommand.CommandText, sqlcommand.Connection);
                DataTable dt4 = new DataTable();
                adapter4.Fill(dt4);

                index = dt4.Rows.Count;
                for (int i = 0; i < index && dt4.Rows[i] != null; i++)
                {
                    dr = dt4.Rows[i];
                    times[i] = dr["accuracy"].ToString();
                }


                if (times[0] != null)
                {
                    squat_accuracy_1st.Text = times[0];
                }
                if (times[1] != null)
                {
                    squat_accuracy_2nd.Text = times[1];
                }
                if (times[2] != null)
                {
                    squat_accuracy_3rd.Text = times[2];
                }
                if (times[3] != null)
                {
                    squat_accuracy_4th.Text = times[3];
                }
                
                sqlConnection.Close();

            }
        }
    }
}